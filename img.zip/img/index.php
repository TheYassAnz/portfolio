<?php

header('Location: https://yassanz.com');
